﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace WindowsFormsApplication1
{
    public partial class editemp : Form
    {
        public editemp()
        {
            InitializeComponent();
        }
        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        private void backBtn_Click(object sender, EventArgs e)
        {
            EmployeeDetails back = new EmployeeDetails();
            back.Show();
            Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PrdctAddbtn_Click(object sender, EventArgs e)
        {
            try
            {// staff details add

                string stid = st_id.Text;
                string stname = st_name.Text;
                string mob = st_mob.Text;
                string add = st_addres.Text;
                string gender;
                if (malebtn.Checked)
                { 
                    gender = "Male";
                }else{
                    gender = " Female";
                }
                string designstion = st_designation.Text;

                // sql quary
                con.Open();
                string st_inst = " INSERT INTO staff VALUES ('" + stid + "', '" + stname + "', '" + mob + "', '" + add + "', '" + gender + "','" + designstion + "')";
                SqlCommand insprdt = new SqlCommand(st_inst, con);
                insprdt.ExecuteNonQuery();

                MessageBox.Show("New Staff Member Registred..");

                // text box clear
                con.Close();
                st_id.Clear();
                st_name.Clear();
                st_mob.Clear();
                con.Close();




            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }


        }

        private void st_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // staff add button
                string stid = st_id.Text;
                string stname = st_name.Text;
                string mob = st_mob.Text;
                string add = st_addres.Text;
                string gender;
                if (malebtn.Checked)
                {
                    gender = "Male";
                }
                else
                {
                    gender = " Female";
                }
                string designstion = st_designation.Text;
                con.Open();
                string update_staff = "UPDATE staff SET Staff_Name = '" + stname + "', Mobilr = '" + mob + "' , Address = '" + add + "' , Gender = '" + gender + "' , Designation = '" + designstion + "'WHERE Staff_id = '" + stid + "'";

                //sql command
                SqlCommand cmd = new SqlCommand(update_staff, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Updated ");

                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }
        }
    }
}
