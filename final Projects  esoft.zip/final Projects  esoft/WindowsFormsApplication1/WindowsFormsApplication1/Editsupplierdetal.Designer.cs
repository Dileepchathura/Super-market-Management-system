﻿namespace WindowsFormsApplication1
{
    partial class Editsupplierdetal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.s_mobile = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.s_name = new System.Windows.Forms.TextBox();
            this.s_address = new System.Windows.Forms.TextBox();
            this.s_code = new System.Windows.Forms.TextBox();
            this.sup_add_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sup_up_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.backBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.backBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.backBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.ForeColor = System.Drawing.Color.Black;
            this.backBtn.Location = new System.Drawing.Point(100, 330);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(75, 23);
            this.backBtn.TabIndex = 40;
            this.backBtn.Text = "Back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(133, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(259, 24);
            this.label7.TabIndex = 39;
            this.label7.Text = "Add or Edit Supplier details";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(52, 102);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 14);
            this.label6.TabIndex = 38;
            this.label6.Text = "Supplier Code";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(52, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 14);
            this.label5.TabIndex = 37;
            this.label5.Text = "Mobile";
            // 
            // s_mobile
            // 
            this.s_mobile.Location = new System.Drawing.Point(164, 207);
            this.s_mobile.Name = "s_mobile";
            this.s_mobile.Size = new System.Drawing.Size(168, 20);
            this.s_mobile.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-106, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 14);
            this.label4.TabIndex = 35;
            this.label4.Text = "Price";
            // 
            // s_name
            // 
            this.s_name.Location = new System.Drawing.Point(164, 131);
            this.s_name.Name = "s_name";
            this.s_name.Size = new System.Drawing.Size(168, 20);
            this.s_name.TabIndex = 34;
            // 
            // s_address
            // 
            this.s_address.Location = new System.Drawing.Point(164, 166);
            this.s_address.Name = "s_address";
            this.s_address.Size = new System.Drawing.Size(168, 20);
            this.s_address.TabIndex = 33;
            // 
            // s_code
            // 
            this.s_code.Location = new System.Drawing.Point(164, 96);
            this.s_code.Name = "s_code";
            this.s_code.Size = new System.Drawing.Size(168, 20);
            this.s_code.TabIndex = 32;
            // 
            // sup_add_btn
            // 
            this.sup_add_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.sup_add_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sup_add_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.sup_add_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sup_add_btn.ForeColor = System.Drawing.Color.Black;
            this.sup_add_btn.Location = new System.Drawing.Point(357, 330);
            this.sup_add_btn.Name = "sup_add_btn";
            this.sup_add_btn.Size = new System.Drawing.Size(75, 23);
            this.sup_add_btn.TabIndex = 31;
            this.sup_add_btn.Text = "Add";
            this.sup_add_btn.UseVisualStyleBackColor = false;
            this.sup_add_btn.Click += new System.EventHandler(this.sup_add_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(-106, -31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 14);
            this.label3.TabIndex = 30;
            this.label3.Text = "Product code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(52, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 14);
            this.label2.TabIndex = 29;
            this.label2.Text = "Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Garamond", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 28;
            this.label1.Text = "Supplier Name";
            // 
            // sup_up_btn
            // 
            this.sup_up_btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.sup_up_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.sup_up_btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.sup_up_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sup_up_btn.ForeColor = System.Drawing.Color.Black;
            this.sup_up_btn.Location = new System.Drawing.Point(235, 330);
            this.sup_up_btn.Name = "sup_up_btn";
            this.sup_up_btn.Size = new System.Drawing.Size(97, 23);
            this.sup_up_btn.TabIndex = 41;
            this.sup_up_btn.Text = "Update";
            this.sup_up_btn.UseVisualStyleBackColor = false;
            this.sup_up_btn.Click += new System.EventHandler(this.sup_up_btn_Click);
            // 
            // Editsupplierdetal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(459, 382);
            this.Controls.Add(this.sup_up_btn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.s_mobile);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.s_name);
            this.Controls.Add(this.s_address);
            this.Controls.Add(this.s_code);
            this.Controls.Add(this.sup_add_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Editsupplierdetal";
            this.Text = "Editsupplierdetal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox s_mobile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox s_name;
        private System.Windows.Forms.TextBox s_address;
        private System.Windows.Forms.TextBox s_code;
        private System.Windows.Forms.Button sup_add_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button sup_up_btn;
    }
}