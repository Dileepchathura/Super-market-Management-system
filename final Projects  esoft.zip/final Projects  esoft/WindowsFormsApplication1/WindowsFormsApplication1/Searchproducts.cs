﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Searchproducts : Form
    {
        

        public Searchproducts()
        {
            InitializeComponent();
        }
        //DB connection

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        private void Editproducts_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stop_ShopDataSet4.products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.stop_ShopDataSet4.products);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SearchPrdtDetals_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddEmpbtn_Click(object sender, EventArgs e)
        {
            Editempdetails prdct = new Editempdetails();
            prdct.Show();
            Visible = false;

           
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            DashBord dash = new DashBord();
            dash.Show();
            Visible = false;
        }

        private void EmpEditBtn_Click(object sender, EventArgs e)
        {
            Editempdetails prdct = new Editempdetails();
            prdct.Show();
            Visible = false;
        }

        private void EmpDelBtn_Click(object sender, EventArgs e)
        {
            try
            { // product delete

                con.Open();
                string Searchpdct = SearchPrdtDetals.Text;

                String Deletepd = "DELETE FROM products WHERE product_code ='" + Searchpdct + "'";
                SqlCommand del = new SqlCommand(Deletepd, con);
                del.ExecuteNonQuery();

                // Delete msg box confamation
                MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                //Massage Delete masage sucessful

               MessageBox.Show("Delete Sucessfull..");

                SearchPrdtDetals.Clear();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }

        private void Searchprdt_Click(object sender, EventArgs e)
        {
            try
            {  
                //search products  

                con.Open();
                string Searchprdct = SearchPrdtDetals.Text;

                //sql quary
                String sqlsearch = "SELECT * FROM products WHERE product_code = '" + Searchprdct + "';";
                SqlDataAdapter sqladp = new SqlDataAdapter(sqlsearch, con);

                // data gerid view
                DataSet aer = new DataSet();
                sqladp.Fill(aer, Searchprdct);
                dataGridViewprdct.DataSource = aer;
                dataGridViewprdct.DataMember = Searchprdct;
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }
    }
}
