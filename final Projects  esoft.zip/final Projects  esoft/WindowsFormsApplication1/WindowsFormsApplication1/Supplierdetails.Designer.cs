﻿namespace WindowsFormsApplication1
{
    partial class Supplierdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BackBtn = new System.Windows.Forms.Button();
            this.EmpDelBtn = new System.Windows.Forms.Button();
            this.EmpEditBtn = new System.Windows.Forms.Button();
            this.AddEmpbtn = new System.Windows.Forms.Button();
            this.Tabale = new System.Windows.Forms.DataGridView();
            this.Search = new System.Windows.Forms.Label();
            this.SearchEmpDetals = new System.Windows.Forms.TextBox();
            this.search_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.stop_ShopDataSet5 = new WindowsFormsApplication1.Stop_ShopDataSet5();
            this.supplierdetails1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.supplier_details1TableAdapter = new WindowsFormsApplication1.Stop_ShopDataSet5TableAdapters.supplier_details1TableAdapter();
            this.supcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supaddresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supmobDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Tabale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierdetails1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackBtn.BackColor = System.Drawing.Color.Cyan;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.Color.Black;
            this.BackBtn.Location = new System.Drawing.Point(617, 379);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(105, 32);
            this.BackBtn.TabIndex = 27;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // EmpDelBtn
            // 
            this.EmpDelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpDelBtn.BackColor = System.Drawing.Color.Red;
            this.EmpDelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpDelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpDelBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpDelBtn.Location = new System.Drawing.Point(616, 314);
            this.EmpDelBtn.Name = "EmpDelBtn";
            this.EmpDelBtn.Size = new System.Drawing.Size(106, 32);
            this.EmpDelBtn.TabIndex = 26;
            this.EmpDelBtn.Text = "Delete ";
            this.EmpDelBtn.UseVisualStyleBackColor = false;
            this.EmpDelBtn.Click += new System.EventHandler(this.EmpDelBtn_Click);
            // 
            // EmpEditBtn
            // 
            this.EmpEditBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpEditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.EmpEditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpEditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpEditBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpEditBtn.Location = new System.Drawing.Point(617, 255);
            this.EmpEditBtn.Name = "EmpEditBtn";
            this.EmpEditBtn.Size = new System.Drawing.Size(106, 36);
            this.EmpEditBtn.TabIndex = 25;
            this.EmpEditBtn.Text = "Edit Details";
            this.EmpEditBtn.UseVisualStyleBackColor = false;
            this.EmpEditBtn.Click += new System.EventHandler(this.EmpEditBtn_Click);
            // 
            // AddEmpbtn
            // 
            this.AddEmpbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddEmpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AddEmpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddEmpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpbtn.ForeColor = System.Drawing.Color.Black;
            this.AddEmpbtn.Location = new System.Drawing.Point(616, 191);
            this.AddEmpbtn.Name = "AddEmpbtn";
            this.AddEmpbtn.Size = new System.Drawing.Size(106, 34);
            this.AddEmpbtn.TabIndex = 24;
            this.AddEmpbtn.Text = "Add New Supplier";
            this.AddEmpbtn.UseVisualStyleBackColor = false;
            this.AddEmpbtn.Click += new System.EventHandler(this.AddEmpbtn_Click);
            // 
            // Tabale
            // 
            this.Tabale.AutoGenerateColumns = false;
            this.Tabale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Tabale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supcodeDataGridViewTextBoxColumn,
            this.supnameDataGridViewTextBoxColumn,
            this.supaddresDataGridViewTextBoxColumn,
            this.supmobDataGridViewTextBoxColumn});
            this.Tabale.DataSource = this.supplierdetails1BindingSource;
            this.Tabale.Location = new System.Drawing.Point(113, 216);
            this.Tabale.Name = "Tabale";
            this.Tabale.Size = new System.Drawing.Size(447, 172);
            this.Tabale.TabIndex = 23;
            this.Tabale.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.EmpTabale_CellContentClick);
            // 
            // Search
            // 
            this.Search.AutoSize = true;
            this.Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search.ForeColor = System.Drawing.Color.Red;
            this.Search.Location = new System.Drawing.Point(58, 105);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(0, 16);
            this.Search.TabIndex = 22;
            // 
            // SearchEmpDetals
            // 
            this.SearchEmpDetals.BackColor = System.Drawing.SystemColors.Info;
            this.SearchEmpDetals.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchEmpDetals.Location = new System.Drawing.Point(133, 160);
            this.SearchEmpDetals.Name = "SearchEmpDetals";
            this.SearchEmpDetals.Size = new System.Drawing.Size(375, 29);
            this.SearchEmpDetals.TabIndex = 21;
            this.SearchEmpDetals.Text = "Enter here Supplier code  & clik on search";
            this.SearchEmpDetals.TextChanged += new System.EventHandler(this.SearchEmpDetals_TextChanged);
            // 
            // search_btn
            // 
            this.search_btn.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.search_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search_btn.ForeColor = System.Drawing.Color.Red;
            this.search_btn.Location = new System.Drawing.Point(616, 121);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(106, 35);
            this.search_btn.TabIndex = 28;
            this.search_btn.Text = "Search";
            this.search_btn.UseVisualStyleBackColor = false;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(180, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(437, 39);
            this.label7.TabIndex = 29;
            this.label7.Text = "Add or Edit  Supplier details";
            // 
            // stop_ShopDataSet5
            // 
            this.stop_ShopDataSet5.DataSetName = "Stop_ShopDataSet5";
            this.stop_ShopDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // supplierdetails1BindingSource
            // 
            this.supplierdetails1BindingSource.DataMember = "supplier_details1";
            this.supplierdetails1BindingSource.DataSource = this.stop_ShopDataSet5;
            // 
            // supplier_details1TableAdapter
            // 
            this.supplier_details1TableAdapter.ClearBeforeFill = true;
            // 
            // supcodeDataGridViewTextBoxColumn
            // 
            this.supcodeDataGridViewTextBoxColumn.DataPropertyName = "sup_code";
            this.supcodeDataGridViewTextBoxColumn.HeaderText = "sup_code";
            this.supcodeDataGridViewTextBoxColumn.Name = "supcodeDataGridViewTextBoxColumn";
            // 
            // supnameDataGridViewTextBoxColumn
            // 
            this.supnameDataGridViewTextBoxColumn.DataPropertyName = "sup_name";
            this.supnameDataGridViewTextBoxColumn.HeaderText = "sup_name";
            this.supnameDataGridViewTextBoxColumn.Name = "supnameDataGridViewTextBoxColumn";
            // 
            // supaddresDataGridViewTextBoxColumn
            // 
            this.supaddresDataGridViewTextBoxColumn.DataPropertyName = "sup_addres";
            this.supaddresDataGridViewTextBoxColumn.HeaderText = "sup_addres";
            this.supaddresDataGridViewTextBoxColumn.Name = "supaddresDataGridViewTextBoxColumn";
            // 
            // supmobDataGridViewTextBoxColumn
            // 
            this.supmobDataGridViewTextBoxColumn.DataPropertyName = "sup_mob";
            this.supmobDataGridViewTextBoxColumn.HeaderText = "sup_mob";
            this.supmobDataGridViewTextBoxColumn.Name = "supmobDataGridViewTextBoxColumn";
            // 
            // Supplierdetails
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.custemer2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(778, 506);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.EmpDelBtn);
            this.Controls.Add(this.EmpEditBtn);
            this.Controls.Add(this.AddEmpbtn);
            this.Controls.Add(this.Tabale);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.SearchEmpDetals);
            this.Name = "Supplierdetails";
            this.Text = "Supplierdetails";
            this.Load += new System.EventHandler(this.Supplierdetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Tabale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierdetails1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button EmpDelBtn;
        private System.Windows.Forms.Button EmpEditBtn;
        private System.Windows.Forms.Button AddEmpbtn;
        private System.Windows.Forms.DataGridView Tabale;
        private System.Windows.Forms.Label Search;
        private System.Windows.Forms.TextBox SearchEmpDetals;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.Label label7;
        private Stop_ShopDataSet5 stop_ShopDataSet5;
        private System.Windows.Forms.BindingSource supplierdetails1BindingSource;
        private Stop_ShopDataSet5TableAdapters.supplier_details1TableAdapter supplier_details1TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supaddresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supmobDataGridViewTextBoxColumn;
    }
}