﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class editcustemer : Form
    {
        public editcustemer()
        {
            InitializeComponent();
        }
        //DB connection

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);


        private void backBtn_Click(object sender, EventArgs e)
        {
            CustomerDetails dash = new CustomerDetails();
            dash.Show();
            Visible = false;
        }

        private void PrdctAddbtn_Click(object sender, EventArgs e)
        {
            try
            {
                // add customer button

                // get data

                string ide = id.Text;
                string namee = name.Text;
                string addrese = address.Text;
                string mobilee = mob.Text;
                string gender;
                if (male.Checked)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                string type = comboBox1.Text;
                
                    DateTime iDate;
                    dateTime.Value = DateTime.Today;
                    iDate = dateTime.Value;

                con.Open();
                // sql quary
                string sqladd = "INSERT INTO customer VALUES ( '" + ide + "' , '" + namee + "' , '" + addrese + "' , '" + mobilee + "' , '" + gender + "' , '" + type + "' ,'" + iDate + "' )";
                SqlCommand comand = new SqlCommand(sqladd,con);
                comand.ExecuteNonQuery();

                MessageBox.Show("Added Sucessfully");
                //CLEAR TEXT BOXES
                id.Clear();
                name.Clear();
                address.Clear();
                mob.Clear();
                male.Checked = false;
                female.Checked = false;
                comboBox1.ResetText();

             }
            catch (Exception ex)

            {
                MessageBox.Show("error while handling" + ex);

            }
            finally
            {
                con.Close();
            }
        }

        private void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                // edit button customer

                // get data
                string ide = id.Text;
                string namee = name.Text;
                string addrese = address.Text;
                string mobilee = mob.Text;
                string gender;
                if (male.Checked)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                string type = comboBox1.Text;

                con.Open();
               // sql quary
                string sqladd = " UPDATE customer SET cus_name = '" + namee + "' , address = '" + addrese + "' , mobile = '" + mobilee + "' , gender = '" + gender + "' , type = '" + type + "' WHERE  cus_id ='" + ide + "' ";
                SqlCommand comand = new SqlCommand(sqladd, con);
                comand.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Updated Sucessfully");

                // CLEAR TEXT BOXES
                id.Clear();
                name.Clear();
                address.Clear();
                mob.Clear();
                male.Checked = false;
                female.Checked = false;
                comboBox1.ResetText();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }
        }
    }
}
