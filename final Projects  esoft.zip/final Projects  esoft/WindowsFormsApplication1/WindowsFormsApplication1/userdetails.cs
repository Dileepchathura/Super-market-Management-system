﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class userdetails : Form
    {
        

        public userdetails()
        {
            InitializeComponent();
        }
        //data base connection

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";

        SqlConnection con = new SqlConnection(connect);

        private void BackBtn_Click(object sender, EventArgs e)
        {
            DashBord dash = new DashBord();
            dash.Show();
            Visible = false;
        }

        private void AddEmpbtn_Click(object sender, EventArgs e)
        {
            Adduser aduser = new Adduser();
            aduser.Show();
            Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void search(string valuetofound)
        {
           
            
        }

        private void userdetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stop_ShopDataSet1.user_details' table. You can move, or remove it, as needed.
            this.user_detailsTableAdapter1.Fill(this.stop_ShopDataSet1.user_details);
            // TODO: This line of code loads data into the 'stop_ShopDataSet.user_details' table. You can move, or remove it, as needed.
            this.user_detailsTableAdapter.Fill(this.stop_ShopDataSet.user_details);
            
        }

        private void Searchbtn_Click(object sender, EventArgs e)
        {
            con.Open();
            string search = Searchuser.Text;

            String tablequary = "SELECT user_id,name,password,address,designation FROM user_details WHERE  user_id  = '" + search + "'";
            SqlDataAdapter ab = new SqlDataAdapter(tablequary, con);
            DataSet a = new DataSet();
            ab.Fill(a, "search");
            dataGridView1.DataSource = a;
            dataGridView1.DataMember = "search";
            con.Close();
            
           


        }

        private void EmpDelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string empid = Searchuser.Text;
                string delete_query = "DELETE FROM user_details WHERE user_id ='" + empid + "';";
                //sql command
                SqlCommand cmd = new SqlCommand(delete_query, con);
                cmd.ExecuteNonQuery();

                // Delete msg box confamation
                MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                MessageBox.Show("Deleted Sucessfully");
                Searchuser.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }

        }

        private void EmpEditBtn_Click(object sender, EventArgs e)
        {
            Adduser userad = new Adduser();
            userad.Show();
            Visible = false;
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void Searchuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
