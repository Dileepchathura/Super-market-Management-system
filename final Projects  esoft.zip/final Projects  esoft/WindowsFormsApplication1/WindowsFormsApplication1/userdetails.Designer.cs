﻿namespace WindowsFormsApplication1
{
    partial class userdetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AddEmpbtn = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.EmpDelBtn = new System.Windows.Forms.Button();
            this.EmpEditBtn = new System.Windows.Forms.Button();
            this.Searchuser = new System.Windows.Forms.TextBox();
            this.Searchbtn = new System.Windows.Forms.Button();
            this.stop_ShopDataSet = new WindowsFormsApplication1.Stop_ShopDataSet();
            this.userdetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.user_detailsTableAdapter = new WindowsFormsApplication1.Stop_ShopDataSetTableAdapters.user_detailsTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userdetailsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.stop_ShopDataSet1 = new WindowsFormsApplication1.Stop_ShopDataSet1();
            this.user_detailsTableAdapter1 = new WindowsFormsApplication1.Stop_ShopDataSet1TableAdapters.user_detailsTableAdapter();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userdetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userdetailsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // AddEmpbtn
            // 
            this.AddEmpbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddEmpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AddEmpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddEmpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpbtn.ForeColor = System.Drawing.Color.Black;
            this.AddEmpbtn.Location = new System.Drawing.Point(589, 150);
            this.AddEmpbtn.Name = "AddEmpbtn";
            this.AddEmpbtn.Size = new System.Drawing.Size(112, 35);
            this.AddEmpbtn.TabIndex = 43;
            this.AddEmpbtn.Text = "Add New User";
            this.AddEmpbtn.UseVisualStyleBackColor = false;
            this.AddEmpbtn.Click += new System.EventHandler(this.AddEmpbtn_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackBtn.BackColor = System.Drawing.Color.Cyan;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.Color.Black;
            this.BackBtn.Location = new System.Drawing.Point(589, 332);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(112, 27);
            this.BackBtn.TabIndex = 46;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // EmpDelBtn
            // 
            this.EmpDelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpDelBtn.BackColor = System.Drawing.Color.Red;
            this.EmpDelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpDelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpDelBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpDelBtn.Location = new System.Drawing.Point(589, 272);
            this.EmpDelBtn.Name = "EmpDelBtn";
            this.EmpDelBtn.Size = new System.Drawing.Size(112, 31);
            this.EmpDelBtn.TabIndex = 45;
            this.EmpDelBtn.Text = "Delete ";
            this.EmpDelBtn.UseVisualStyleBackColor = false;
            this.EmpDelBtn.Click += new System.EventHandler(this.EmpDelBtn_Click);
            // 
            // EmpEditBtn
            // 
            this.EmpEditBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpEditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.EmpEditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpEditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpEditBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpEditBtn.Location = new System.Drawing.Point(589, 214);
            this.EmpEditBtn.Name = "EmpEditBtn";
            this.EmpEditBtn.Size = new System.Drawing.Size(112, 34);
            this.EmpEditBtn.TabIndex = 44;
            this.EmpEditBtn.Text = "Edit Details";
            this.EmpEditBtn.UseVisualStyleBackColor = false;
            this.EmpEditBtn.Click += new System.EventHandler(this.EmpEditBtn_Click);
            // 
            // Searchuser
            // 
            this.Searchuser.BackColor = System.Drawing.SystemColors.Info;
            this.Searchuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchuser.Location = new System.Drawing.Point(126, 93);
            this.Searchuser.Name = "Searchuser";
            this.Searchuser.Size = new System.Drawing.Size(399, 31);
            this.Searchuser.TabIndex = 40;
            this.Searchuser.Text = "Enter here User id  & clik on search";
            this.Searchuser.TextChanged += new System.EventHandler(this.Searchuser_TextChanged);
            // 
            // Searchbtn
            // 
            this.Searchbtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Searchbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Searchbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchbtn.ForeColor = System.Drawing.Color.Red;
            this.Searchbtn.Location = new System.Drawing.Point(589, 93);
            this.Searchbtn.Name = "Searchbtn";
            this.Searchbtn.Size = new System.Drawing.Size(112, 31);
            this.Searchbtn.TabIndex = 48;
            this.Searchbtn.Text = "Search";
            this.Searchbtn.UseVisualStyleBackColor = false;
            this.Searchbtn.Click += new System.EventHandler(this.Searchbtn_Click);
            // 
            // stop_ShopDataSet
            // 
            this.stop_ShopDataSet.DataSetName = "Stop_ShopDataSet";
            this.stop_ShopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // userdetailsBindingSource
            // 
            this.userdetailsBindingSource.DataMember = "user_details";
            this.userdetailsBindingSource.DataSource = this.stop_ShopDataSet;
            // 
            // user_detailsTableAdapter
            // 
            this.user_detailsTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.useridDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.designationDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.userdetailsBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(74, 166);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(441, 217);
            this.dataGridView1.TabIndex = 49;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_2);
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "user_id";
            this.useridDataGridViewTextBoxColumn.HeaderText = "user_id";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "password";
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // designationDataGridViewTextBoxColumn
            // 
            this.designationDataGridViewTextBoxColumn.DataPropertyName = "designation";
            this.designationDataGridViewTextBoxColumn.HeaderText = "designation";
            this.designationDataGridViewTextBoxColumn.Name = "designationDataGridViewTextBoxColumn";
            // 
            // userdetailsBindingSource1
            // 
            this.userdetailsBindingSource1.DataMember = "user_details";
            this.userdetailsBindingSource1.DataSource = this.stop_ShopDataSet1;
            // 
            // stop_ShopDataSet1
            // 
            this.stop_ShopDataSet1.DataSetName = "Stop_ShopDataSet1";
            this.stop_ShopDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // user_detailsTableAdapter1
            // 
            this.user_detailsTableAdapter1.ClearBeforeFill = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(187, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(291, 30);
            this.label7.TabIndex = 56;
            this.label7.Text = "Add or Edit User details";
            // 
            // userdetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.download__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(794, 459);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Searchbtn);
            this.Controls.Add(this.AddEmpbtn);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.EmpDelBtn);
            this.Controls.Add(this.EmpEditBtn);
            this.Controls.Add(this.Searchuser);
            this.Name = "userdetails";
            this.Text = "userdetails";
            this.Load += new System.EventHandler(this.userdetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userdetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userdetailsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddEmpbtn;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button EmpDelBtn;
        private System.Windows.Forms.Button EmpEditBtn;
        private System.Windows.Forms.TextBox Searchuser;
        private System.Windows.Forms.Button Searchbtn;
        private Stop_ShopDataSet stop_ShopDataSet;
        private System.Windows.Forms.BindingSource userdetailsBindingSource;
        private Stop_ShopDataSetTableAdapters.user_detailsTableAdapter user_detailsTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Stop_ShopDataSet1 stop_ShopDataSet1;
        private System.Windows.Forms.BindingSource userdetailsBindingSource1;
        private Stop_ShopDataSet1TableAdapters.user_detailsTableAdapter user_detailsTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label7;
    }
}