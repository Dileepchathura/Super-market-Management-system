﻿namespace WindowsFormsApplication1
{
    partial class CustomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Searchcus = new System.Windows.Forms.TextBox();
            this.custEditBtn = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.cusidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cusnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobileDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dOBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stop_ShopDataSet2 = new WindowsFormsApplication1.Stop_ShopDataSet2();
            this.label7 = new System.Windows.Forms.Label();
            this.AddEmpbtn = new System.Windows.Forms.Button();
            this.CustDelBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.customerTableAdapter = new WindowsFormsApplication1.Stop_ShopDataSet2TableAdapters.customerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // Searchcus
            // 
            this.Searchcus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchcus.Location = new System.Drawing.Point(84, 119);
            this.Searchcus.Name = "Searchcus";
            this.Searchcus.Size = new System.Drawing.Size(428, 29);
            this.Searchcus.TabIndex = 3;
            this.Searchcus.Text = "Enter here Customer id  & clik on search\r\n";
            // 
            // custEditBtn
            // 
            this.custEditBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.custEditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.custEditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.custEditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.custEditBtn.ForeColor = System.Drawing.Color.Black;
            this.custEditBtn.Location = new System.Drawing.Point(613, 262);
            this.custEditBtn.Name = "custEditBtn";
            this.custEditBtn.Size = new System.Drawing.Size(121, 31);
            this.custEditBtn.TabIndex = 6;
            this.custEditBtn.Text = "Edit Custemer";
            this.custEditBtn.UseVisualStyleBackColor = false;
            this.custEditBtn.Click += new System.EventHandler(this.custEditBtn_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cusidDataGridViewTextBoxColumn,
            this.cusnameDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.mobileDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.dOBDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.customerBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(24, 191);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(583, 193);
            this.dataGridView2.TabIndex = 13;
            // 
            // cusidDataGridViewTextBoxColumn
            // 
            this.cusidDataGridViewTextBoxColumn.DataPropertyName = "cus_id";
            this.cusidDataGridViewTextBoxColumn.HeaderText = "cus_id";
            this.cusidDataGridViewTextBoxColumn.Name = "cusidDataGridViewTextBoxColumn";
            // 
            // cusnameDataGridViewTextBoxColumn
            // 
            this.cusnameDataGridViewTextBoxColumn.DataPropertyName = "cus_name";
            this.cusnameDataGridViewTextBoxColumn.HeaderText = "cus_name";
            this.cusnameDataGridViewTextBoxColumn.Name = "cusnameDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // mobileDataGridViewTextBoxColumn
            // 
            this.mobileDataGridViewTextBoxColumn.DataPropertyName = "mobile";
            this.mobileDataGridViewTextBoxColumn.HeaderText = "mobile";
            this.mobileDataGridViewTextBoxColumn.Name = "mobileDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // typeDataGridViewTextBoxColumn
            // 
            this.typeDataGridViewTextBoxColumn.DataPropertyName = "type";
            this.typeDataGridViewTextBoxColumn.HeaderText = "type";
            this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
            // 
            // dOBDataGridViewTextBoxColumn
            // 
            this.dOBDataGridViewTextBoxColumn.DataPropertyName = "DOB";
            this.dOBDataGridViewTextBoxColumn.HeaderText = "DOB";
            this.dOBDataGridViewTextBoxColumn.Name = "dOBDataGridViewTextBoxColumn";
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "customer";
            this.customerBindingSource.DataSource = this.stop_ShopDataSet2;
            // 
            // stop_ShopDataSet2
            // 
            this.stop_ShopDataSet2.DataSetName = "Stop_ShopDataSet2";
            this.stop_ShopDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(139, 44);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(373, 33);
            this.label7.TabIndex = 27;
            this.label7.Text = "Add or Edit Custemer details";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // AddEmpbtn
            // 
            this.AddEmpbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddEmpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AddEmpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddEmpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpbtn.ForeColor = System.Drawing.Color.Black;
            this.AddEmpbtn.Location = new System.Drawing.Point(613, 186);
            this.AddEmpbtn.Name = "AddEmpbtn";
            this.AddEmpbtn.Size = new System.Drawing.Size(121, 31);
            this.AddEmpbtn.TabIndex = 29;
            this.AddEmpbtn.Text = "Add New Custemer";
            this.AddEmpbtn.UseVisualStyleBackColor = false;
            this.AddEmpbtn.Click += new System.EventHandler(this.AddEmpbtn_Click);
            // 
            // CustDelBtn
            // 
            this.CustDelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CustDelBtn.BackColor = System.Drawing.Color.Red;
            this.CustDelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CustDelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustDelBtn.ForeColor = System.Drawing.Color.Black;
            this.CustDelBtn.Location = new System.Drawing.Point(613, 320);
            this.CustDelBtn.Name = "CustDelBtn";
            this.CustDelBtn.Size = new System.Drawing.Size(121, 31);
            this.CustDelBtn.TabIndex = 30;
            this.CustDelBtn.Text = "Delete ";
            this.CustDelBtn.UseVisualStyleBackColor = false;
            this.CustDelBtn.Click += new System.EventHandler(this.CustDelBtn_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(613, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 32);
            this.button1.TabIndex = 31;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(613, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(122, 31);
            this.button2.TabIndex = 32;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.customer_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(789, 521);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CustDelBtn);
            this.Controls.Add(this.AddEmpbtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.custEditBtn);
            this.Controls.Add(this.Searchcus);
            this.Name = "CustomerDetails";
            this.Text = "CustemerDetails";
            this.Load += new System.EventHandler(this.CustomerDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Searchcus;
        private System.Windows.Forms.Button custEditBtn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button AddEmpbtn;
        private System.Windows.Forms.Button CustDelBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private Stop_ShopDataSet2 stop_ShopDataSet2;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private Stop_ShopDataSet2TableAdapters.customerTableAdapter customerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cusnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobileDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dOBDataGridViewTextBoxColumn;
    }
}