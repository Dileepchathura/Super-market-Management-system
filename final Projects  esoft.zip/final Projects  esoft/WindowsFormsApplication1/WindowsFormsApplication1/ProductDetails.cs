﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class CustomerDetails : Form
    {
        public CustomerDetails()
        {
            InitializeComponent();
        }
        //data base connection

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";

        SqlConnection con = new SqlConnection(connect);

        private void PrdctAddbtn_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void AddEmpbtn_Click(object sender, EventArgs e)
        {
            editcustemer cus = new editcustemer();
            cus.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DashBord dash = new DashBord();
            dash.Show();
            Visible = false;
        }

        private void CustomerDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stop_ShopDataSet2.customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.stop_ShopDataSet2.customer);

        }

        private void CustDelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string cus_del = Searchcus.Text;
                string delete_query = "DELETE FROM customer WHERE cus_id ='" + cus_del + "'";
                //sql command
                SqlCommand cmd = new SqlCommand(delete_query, con);
                cmd.ExecuteNonQuery();

                // Delete msg box confamation
                MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                MessageBox.Show("Deleted Sucessfully");
                Searchcus.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            { // take serch key word in to system

                
                string Searchc= Searchcus.Text;

                con.Open();
                //sql quary
                String sqlsearch = "SELECT * FROM customer WHERE cus_id = '" + Searchc + "';";

                SqlDataAdapter sqladp = new SqlDataAdapter(sqlsearch, con);
                DataSet ae = new DataSet();
                sqladp.Fill(ae, "SearchEmpDe");
                dataGridView2.DataSource = ae;
                dataGridView2.DataMember = "SearchEmpDe";
                con.Close();
                Searchcus.Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }

        private void custEditBtn_Click(object sender, EventArgs e)
        {
            editcustemer pdt = new editcustemer();
            pdt.Show();
            Visible = false;
           
        }
    }
}
