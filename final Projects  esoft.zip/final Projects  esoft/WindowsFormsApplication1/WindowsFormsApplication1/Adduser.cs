﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Adduser : Form

    {
        // connection DB
        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);
        
      
            
        public Adduser()
        {
            InitializeComponent();

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            userdetails usert = new userdetails();
            usert.Show();
            Visible = false;
        }

        private void PrdctAddbtn_Click(object sender, EventArgs e)
        {

            
           //get data from insert user inter face

            try
            {
                string id = useridget.Text;
                string name = nameget.Text;
                string password = passwordget.Text;
                string address = adressget.Text;
                string Designation = desingaget.Text;


                // sql comand
                string sqlquary = " INSERT INTO user_details VALUES('" + id + "','" + name + "','" + password + "','" + address + "','" + Designation + "')";

                SqlCommand com = new SqlCommand(sqlquary, con);
                con.Open();
                com.ExecuteNonQuery();

                // massege box
                MessageBox.Show("User Registration Sucessfull...");

                con.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }
            
            }

        private void button1_Click(object sender, EventArgs e)
        {
           // update user details
            //get data from insert user inter face
            try
            {

                string id = useridget.Text;
                string name = nameget.Text;
                string password = passwordget.Text;
                string address = adressget.Text;
                string Designation = desingaget.Text;


                // sql comand
                con.Open();
                string sqlquaryupdate = " UPDATE  from user_details SET name ='" + name + "',password ='" + password + "',address ='" + address + "',Designation='" + Designation + "'";
                SqlCommand com = new SqlCommand(sqlquaryupdate, con);
                
                com.ExecuteNonQuery();

                // massege box
                MessageBox.Show("User Details updated....");

                con.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
                  }
             }

        private void nameget_TextChanged(object sender, EventArgs e)
        {

        }
        }
    }

