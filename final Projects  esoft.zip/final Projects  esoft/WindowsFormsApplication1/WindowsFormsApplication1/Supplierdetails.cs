﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Supplierdetails : Form
    {
        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        public Supplierdetails()
        {
            InitializeComponent();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            DashBord dash = new DashBord();
            dash.Show();
            Visible = false;
        }

        private void AddEmpbtn_Click(object sender, EventArgs e)
        {
            Editsupplierdetal supe =new Editsupplierdetal();
            supe.Show();
            Visible = false;

        }

        private void EmpDelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // delete supplier
                con.Open();
                string SearchEmpDe = SearchEmpDetals.Text;
                String Delete = "DELETE FROM supplier_details1 WHERE sup_code ='" + SearchEmpDe + "'";
                SqlCommand del = new SqlCommand(Delete, con);
                del.ExecuteNonQuery();

                // Delete msg box confamation
                MessageBox.Show("Do You Want Delete ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                MessageBox.Show ("Delete Sucessfull..");
                SearchEmpDetals.Clear();
                con.Close();

            }
             catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
           
             }

        private void EmpEditBtn_Click(object sender, EventArgs e)
        {
            Editsupplierdetal sup =new Editsupplierdetal();
            sup.Show();
            Visible = false;
        }

        private void SearchEmpDetals_TextChanged(object sender, EventArgs e)
        {

        }

        private void Supplierdetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stop_ShopDataSet5.supplier_details1' table. You can move, or remove it, as needed.
            this.supplier_details1TableAdapter.Fill(this.stop_ShopDataSet5.supplier_details1);
        }   

        private void EmpTabale_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            try
            { // take serch key word in to system

                con.Open();
                string SearchEmpDe = SearchEmpDetals.Text;


                String sqlsearch = "SELECT * FROM supplier_details1 WHERE sup_code = '" + SearchEmpDe + "';";

                SqlDataAdapter sqladp = new SqlDataAdapter(sqlsearch,con);
                DataSet ae = new DataSet();
                sqladp.Fill(ae, "SearchEmpDe");
                Tabale.DataSource = ae;
                Tabale.DataMember = "SearchEmpDe";
                con.Close();

        }catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }

             }
          }

      }


