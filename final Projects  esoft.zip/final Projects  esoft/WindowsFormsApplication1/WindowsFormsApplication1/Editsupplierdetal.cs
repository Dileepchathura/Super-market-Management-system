﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Editsupplierdetal : Form
    {

      

        public Editsupplierdetal()
        {
            InitializeComponent();
        }

        // connection DB
        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        private void backBtn_Click(object sender, EventArgs e)
        {
            Supplierdetails dash = new Supplierdetails();
            dash.Show();
            Visible = false;
        }

        private void sup_add_btn_Click(object sender, EventArgs e)
        // get data from suppliertable
        {
            try
            {
                // add button suplier
                string code = s_code.Text;
                string name = s_name.Text;
                string addres = s_address.Text;
                String mobile = s_mobile.Text;


                // sql comand
                string sqlquary = " INSERT INTO supplier_details1 VALUES('" + code + "','" + name + "','" + addres + "','" + mobile + "')";

               

                SqlCommand com = new SqlCommand(sqlquary, con);
                con.Open();
                com.ExecuteNonQuery();

                // massege box
                //MessageBox.Show("Supplier Registration Sucessfull...");
                MessageBox.Show("Supplier register", "Supplier Registration Sucessfull...",
                 MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }

        }

        private void sup_up_btn_Click(object sender, EventArgs e)
        {
            // suplier details edit button
            try
    {
        string code = s_code.Text;
        string name = s_name.Text;
        string addres = s_address.Text;
        string mobile = s_mobile.Text;
        con.Open();
                // data base connaction
        string sqlquaryupdate = "UPDATE supplier_details1 SET sup_name = '" + name + "', sup_addres = '" + addres + "', sup_mob = '" + mobile + "' WHERE sup_code = '" + code + "'";
        SqlCommand sqlup = new SqlCommand(sqlquaryupdate, con);
        
        sqlup.ExecuteNonQuery();

        MessageBox.Show("User details updated.");

        con.Close();

        s_code.Clear();
        s_name.Clear();
        s_address.Clear();
        s_mobile.Clear();
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error while updating user details: " + ex.Message);
    }
        }
    }
}
