﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Editempdetails : Form
    {

        


        public Editempdetails()
        {
            InitializeComponent();
        }
        //DB connection

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        private void Editempdetails_Load(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            // Back to search product teable menu

            Searchproducts emp = new Searchproducts();
            emp.Show();
            Visible = false;
        }

        private void PrdctAddbtn_Click(object sender, EventArgs e)
        {
 try
            {
     // add product btn

     // collect user input 

            string code = pcode.Text;
            string name = pname.Text;
            string psize = size.Text;
            string pprice = price.Text;
            string cate = cmb_prdct.Text;
     
     //insert quary
            con.Open();
            string PRDCTTB = " INSERT INTO products VALUES ('"+code+"', '"+name+"', '"+psize+"', '"+pprice+"' ,'"+cate+"')";
            SqlCommand insprdt =new SqlCommand(PRDCTTB,con);
            insprdt.ExecuteNonQuery();
     //Massege box
            MessageBox.Show("New Product Added..");
     // user filld clear
            con.Close();
            pcode.Clear();
            pname.Clear();
            size.Clear();
            price.Clear();
           cmb_prdct.ResetText();




            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
        // Edit product details btn

       // collect user input
            string code = pcode.Text;
            string name = pname.Text;
            string psize = size.Text;
            string pprice = price.Text;
            string cate = cmb_prdct.Text;
        
        //update quray
                con.Open();
                string prdtedit = " UPDATE products SET product_name = '" + name + "', pack_size = '" + psize + "', price = '" + pprice + "' , cat = '" + cate + "' WHERE product_code ='" + code + "'"; 
                SqlCommand editpdct = new SqlCommand(prdtedit,con);

                editpdct.ExecuteNonQuery();
       //Massege box
                MessageBox.Show("Product Details Updated....");

       // user filld clear
            pcode.Clear();
            pname.Clear();
            size.Clear();
            price.Clear();
            cmb_prdct.ResetText();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error while handling" + ex);
            }
            
        }
    }
}
