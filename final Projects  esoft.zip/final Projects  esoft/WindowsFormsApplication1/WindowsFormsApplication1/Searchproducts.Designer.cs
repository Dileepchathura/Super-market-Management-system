﻿namespace WindowsFormsApplication1
{
    partial class Searchproducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SearchPrdtDetals = new System.Windows.Forms.TextBox();
            this.dataGridViewprdct = new System.Windows.Forms.DataGridView();
            this.productcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.packsizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.catDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stop_ShopDataSet4 = new WindowsFormsApplication1.Stop_ShopDataSet4();
            this.AddEmpbtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.EmpDelBtn = new System.Windows.Forms.Button();
            this.EmpEditBtn = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.Searchprdt = new System.Windows.Forms.Button();
            this.productsTableAdapter = new WindowsFormsApplication1.Stop_ShopDataSet4TableAdapters.productsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewprdct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchPrdtDetals
            // 
            this.SearchPrdtDetals.BackColor = System.Drawing.SystemColors.Info;
            this.SearchPrdtDetals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SearchPrdtDetals.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchPrdtDetals.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.SearchPrdtDetals.Location = new System.Drawing.Point(93, 125);
            this.SearchPrdtDetals.Name = "SearchPrdtDetals";
            this.SearchPrdtDetals.Size = new System.Drawing.Size(503, 35);
            this.SearchPrdtDetals.TabIndex = 0;
            this.SearchPrdtDetals.Text = "Enter here product code  & clik on search";
            this.SearchPrdtDetals.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.SearchPrdtDetals.TextChanged += new System.EventHandler(this.SearchPrdtDetals_TextChanged);
            // 
            // dataGridViewprdct
            // 
            this.dataGridViewprdct.AutoGenerateColumns = false;
            this.dataGridViewprdct.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridViewprdct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewprdct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productcodeDataGridViewTextBoxColumn,
            this.productnameDataGridViewTextBoxColumn,
            this.packsizeDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.catDataGridViewTextBoxColumn});
            this.dataGridViewprdct.DataSource = this.productsBindingSource;
            this.dataGridViewprdct.Location = new System.Drawing.Point(62, 215);
            this.dataGridViewprdct.Name = "dataGridViewprdct";
            this.dataGridViewprdct.Size = new System.Drawing.Size(543, 142);
            this.dataGridViewprdct.TabIndex = 1;
            this.dataGridViewprdct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // productcodeDataGridViewTextBoxColumn
            // 
            this.productcodeDataGridViewTextBoxColumn.DataPropertyName = "product_code";
            this.productcodeDataGridViewTextBoxColumn.HeaderText = "product_code";
            this.productcodeDataGridViewTextBoxColumn.Name = "productcodeDataGridViewTextBoxColumn";
            // 
            // productnameDataGridViewTextBoxColumn
            // 
            this.productnameDataGridViewTextBoxColumn.DataPropertyName = "product_name";
            this.productnameDataGridViewTextBoxColumn.HeaderText = "product_name";
            this.productnameDataGridViewTextBoxColumn.Name = "productnameDataGridViewTextBoxColumn";
            // 
            // packsizeDataGridViewTextBoxColumn
            // 
            this.packsizeDataGridViewTextBoxColumn.DataPropertyName = "pack_size";
            this.packsizeDataGridViewTextBoxColumn.HeaderText = "pack_size";
            this.packsizeDataGridViewTextBoxColumn.Name = "packsizeDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // catDataGridViewTextBoxColumn
            // 
            this.catDataGridViewTextBoxColumn.DataPropertyName = "cat";
            this.catDataGridViewTextBoxColumn.HeaderText = "cat";
            this.catDataGridViewTextBoxColumn.Name = "catDataGridViewTextBoxColumn";
            // 
            // productsBindingSource
            // 
            this.productsBindingSource.DataMember = "products";
            this.productsBindingSource.DataSource = this.stop_ShopDataSet4;
            // 
            // stop_ShopDataSet4
            // 
            this.stop_ShopDataSet4.DataSetName = "Stop_ShopDataSet4";
            this.stop_ShopDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // AddEmpbtn
            // 
            this.AddEmpbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddEmpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AddEmpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddEmpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpbtn.ForeColor = System.Drawing.Color.Black;
            this.AddEmpbtn.Location = new System.Drawing.Point(650, 195);
            this.AddEmpbtn.Name = "AddEmpbtn";
            this.AddEmpbtn.Size = new System.Drawing.Size(125, 35);
            this.AddEmpbtn.TabIndex = 18;
            this.AddEmpbtn.Text = "Add New Product";
            this.AddEmpbtn.UseVisualStyleBackColor = false;
            this.AddEmpbtn.Click += new System.EventHandler(this.AddEmpbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(155, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(432, 39);
            this.label7.TabIndex = 28;
            this.label7.Text = "Add or Edit  Product details";
            // 
            // EmpDelBtn
            // 
            this.EmpDelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpDelBtn.BackColor = System.Drawing.Color.Red;
            this.EmpDelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpDelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpDelBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpDelBtn.Location = new System.Drawing.Point(650, 343);
            this.EmpDelBtn.Name = "EmpDelBtn";
            this.EmpDelBtn.Size = new System.Drawing.Size(125, 37);
            this.EmpDelBtn.TabIndex = 30;
            this.EmpDelBtn.Text = "Delete ";
            this.EmpDelBtn.UseVisualStyleBackColor = false;
            this.EmpDelBtn.Click += new System.EventHandler(this.EmpDelBtn_Click);
            // 
            // EmpEditBtn
            // 
            this.EmpEditBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpEditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.EmpEditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpEditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpEditBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpEditBtn.Location = new System.Drawing.Point(650, 268);
            this.EmpEditBtn.Name = "EmpEditBtn";
            this.EmpEditBtn.Size = new System.Drawing.Size(125, 39);
            this.EmpEditBtn.TabIndex = 29;
            this.EmpEditBtn.Text = "Edit Details";
            this.EmpEditBtn.UseVisualStyleBackColor = false;
            this.EmpEditBtn.Click += new System.EventHandler(this.EmpEditBtn_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackBtn.BackColor = System.Drawing.Color.Aqua;
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.Color.Black;
            this.BackBtn.Location = new System.Drawing.Point(650, 421);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(125, 39);
            this.BackBtn.TabIndex = 31;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // Searchprdt
            // 
            this.Searchprdt.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Searchprdt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Searchprdt.ForeColor = System.Drawing.Color.Red;
            this.Searchprdt.Location = new System.Drawing.Point(650, 125);
            this.Searchprdt.Name = "Searchprdt";
            this.Searchprdt.Size = new System.Drawing.Size(125, 40);
            this.Searchprdt.TabIndex = 33;
            this.Searchprdt.Text = "Search";
            this.Searchprdt.UseVisualStyleBackColor = false;
            this.Searchprdt.Click += new System.EventHandler(this.Searchprdt_Click);
            // 
            // productsTableAdapter
            // 
            this.productsTableAdapter.ClearBeforeFill = true;
            // 
            // Searchproducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.download__1_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(793, 497);
            this.Controls.Add(this.Searchprdt);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.EmpDelBtn);
            this.Controls.Add(this.EmpEditBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.AddEmpbtn);
            this.Controls.Add(this.dataGridViewprdct);
            this.Controls.Add(this.SearchPrdtDetals);
            this.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.Name = "Searchproducts";
            this.Text = "Editproducts";
            this.Load += new System.EventHandler(this.Editproducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewprdct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SearchPrdtDetals;
        private System.Windows.Forms.DataGridView dataGridViewprdct;
        private System.Windows.Forms.Button AddEmpbtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button EmpDelBtn;
        private System.Windows.Forms.Button EmpEditBtn;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button Searchprdt;
        private Stop_ShopDataSet4 stop_ShopDataSet4;
        private System.Windows.Forms.BindingSource productsBindingSource;
        private Stop_ShopDataSet4TableAdapters.productsTableAdapter productsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn productcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn packsizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn catDataGridViewTextBoxColumn;


    }
}