﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class login : Form
    {

        public login()
        {
            InitializeComponent();
        }

       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            // login

            // take data from login from
            string uname = UserNameBox.Text;
            string pswwd = PassWordBox.Text;
           

            string name = "dileep";
            string psword = "1234";

            //cheeak user name & pasword

            if (uname == name && pswwd == psword)
            {
               
                DashBord login = new DashBord();
                login.Show();
                Visible = false;
                this.timer1.Start();
               
            }
            else
            {
                //Massege box
                MessageBox.Show("Plese Cheak user name & Password", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
 
                
                UserNameBox.Clear();
                PassWordBox.Clear();
            }        
        }

        private void progressBarLoad_Click(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBarLoad.Increment(1);
           
              
        }

        private void QuitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void UserNameBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
