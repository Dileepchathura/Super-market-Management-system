﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace WindowsFormsApplication1
{
    public partial class EmployeeDetails : Form
    {
        public EmployeeDetails()
        {
            InitializeComponent();
        }

        static string connect = "Data Source=DESKTOP-E9EKVPT\\SQLEXPRESS;Initial Catalog=Stop_Shop;Integrated Security=True";
        SqlConnection con = new SqlConnection(connect);

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AddEmpbtn_Click(object sender, EventArgs e)
        {
            editemp emp = new editemp();
            emp.Show();
            Visible = false;
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            DashBord dash = new DashBord();
            dash.Show();
            Visible = false;
        }

        private void EmpEditBtn_Click(object sender, EventArgs e)
        {
            editemp emp = new editemp();
            emp.Show();
            Visible = false;
        }

        private void EmpDelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // deleate staff details
                con.Open();
                string EmpDel = SearchEmpDetals.Text;

                // sql quary
                String Delete = "DELETE FROM staff WHERE Staff_id ='" + EmpDel + "'";
                SqlCommand del = new SqlCommand(Delete, con);
                del.ExecuteNonQuery();

                
                // Delete masage sucessful
                MessageBox.Show("Delete Sucessfull..");

                SearchEmpDetals.Clear();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            { // take serch key word in to system

                con.Open();
                string SearchEmpDe = SearchEmpDetals.Text;

                // sql quary
                String sqlsearch = "SELECT * FROM staff WHERE Staff_id = '" + SearchEmpDe + "';";

                SqlDataAdapter sqladp = new SqlDataAdapter(sqlsearch, con);
                DataSet ae = new DataSet();
                sqladp.Fill(ae, "SearchEmpDe");
                EmpTabale.DataSource = ae;
                EmpTabale.DataMember = "SearchEmpDe";
            }
            catch (Exception ex)
            {
                MessageBox.Show("error handling" + ex);
                con.Close();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void EmployeeDetails_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stop_ShopDataSet3.staff' table. You can move, or remove it, as needed.
            this.staffTableAdapter.Fill(this.stop_ShopDataSet3.staff);

        }
    }
}
