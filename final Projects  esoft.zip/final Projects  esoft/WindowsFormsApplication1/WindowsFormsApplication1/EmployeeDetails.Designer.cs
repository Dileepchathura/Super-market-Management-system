﻿namespace WindowsFormsApplication1
{
    partial class EmployeeDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SearchEmpDetals = new System.Windows.Forms.TextBox();
            this.EmpTabale = new System.Windows.Forms.DataGridView();
            this.EmpDelBtn = new System.Windows.Forms.Button();
            this.EmpEditBtn = new System.Windows.Forms.Button();
            this.AddEmpbtn = new System.Windows.Forms.Button();
            this.BackBtn = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.stop_ShopDataSet3 = new WindowsFormsApplication1.Stop_ShopDataSet3();
            this.staffBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.staffTableAdapter = new WindowsFormsApplication1.Stop_ShopDataSet3TableAdapters.staffTableAdapter();
            this.staffidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobilrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.designationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.EmpTabale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SearchEmpDetals
            // 
            this.SearchEmpDetals.BackColor = System.Drawing.SystemColors.Info;
            this.SearchEmpDetals.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchEmpDetals.Location = new System.Drawing.Point(156, 122);
            this.SearchEmpDetals.Margin = new System.Windows.Forms.Padding(4);
            this.SearchEmpDetals.Name = "SearchEmpDetals";
            this.SearchEmpDetals.Size = new System.Drawing.Size(448, 31);
            this.SearchEmpDetals.TabIndex = 3;
            this.SearchEmpDetals.Text = "Enter here Emp code  & clik on search";
            // 
            // EmpTabale
            // 
            this.EmpTabale.AutoGenerateColumns = false;
            this.EmpTabale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.EmpTabale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffidDataGridViewTextBoxColumn,
            this.staffNameDataGridViewTextBoxColumn,
            this.mobilrDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.designationDataGridViewTextBoxColumn});
            this.EmpTabale.DataSource = this.staffBindingSource;
            this.EmpTabale.Location = new System.Drawing.Point(55, 174);
            this.EmpTabale.Margin = new System.Windows.Forms.Padding(4);
            this.EmpTabale.Name = "EmpTabale";
            this.EmpTabale.Size = new System.Drawing.Size(562, 156);
            this.EmpTabale.TabIndex = 6;
            this.EmpTabale.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // EmpDelBtn
            // 
            this.EmpDelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpDelBtn.BackColor = System.Drawing.Color.Red;
            this.EmpDelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpDelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpDelBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpDelBtn.Location = new System.Drawing.Point(655, 298);
            this.EmpDelBtn.Margin = new System.Windows.Forms.Padding(4);
            this.EmpDelBtn.Name = "EmpDelBtn";
            this.EmpDelBtn.Size = new System.Drawing.Size(127, 32);
            this.EmpDelBtn.TabIndex = 19;
            this.EmpDelBtn.Text = "Delete ";
            this.EmpDelBtn.UseVisualStyleBackColor = false;
            this.EmpDelBtn.Click += new System.EventHandler(this.EmpDelBtn_Click);
            // 
            // EmpEditBtn
            // 
            this.EmpEditBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EmpEditBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.EmpEditBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EmpEditBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmpEditBtn.ForeColor = System.Drawing.Color.Black;
            this.EmpEditBtn.Location = new System.Drawing.Point(655, 229);
            this.EmpEditBtn.Margin = new System.Windows.Forms.Padding(4);
            this.EmpEditBtn.Name = "EmpEditBtn";
            this.EmpEditBtn.Size = new System.Drawing.Size(127, 36);
            this.EmpEditBtn.TabIndex = 18;
            this.EmpEditBtn.Text = "Edit Details";
            this.EmpEditBtn.UseVisualStyleBackColor = false;
            this.EmpEditBtn.Click += new System.EventHandler(this.EmpEditBtn_Click);
            // 
            // AddEmpbtn
            // 
            this.AddEmpbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AddEmpbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.AddEmpbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddEmpbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddEmpbtn.ForeColor = System.Drawing.Color.Black;
            this.AddEmpbtn.Location = new System.Drawing.Point(655, 164);
            this.AddEmpbtn.Margin = new System.Windows.Forms.Padding(4);
            this.AddEmpbtn.Name = "AddEmpbtn";
            this.AddEmpbtn.Size = new System.Drawing.Size(127, 37);
            this.AddEmpbtn.TabIndex = 17;
            this.AddEmpbtn.Text = "Add Employe";
            this.AddEmpbtn.UseVisualStyleBackColor = false;
            this.AddEmpbtn.Click += new System.EventHandler(this.AddEmpbtn_Click);
            // 
            // BackBtn
            // 
            this.BackBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.ForeColor = System.Drawing.Color.Black;
            this.BackBtn.Location = new System.Drawing.Point(655, 356);
            this.BackBtn.Margin = new System.Windows.Forms.Padding(4);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(127, 35);
            this.BackBtn.TabIndex = 20;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = false;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.Red;
            this.btn_search.Location = new System.Drawing.Point(655, 101);
            this.btn_search.Margin = new System.Windows.Forms.Padding(4);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(127, 39);
            this.btn_search.TabIndex = 21;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Garamond", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label7.Location = new System.Drawing.Point(169, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(448, 39);
            this.label7.TabIndex = 29;
            this.label7.Text = "Add or Edit  Employe details";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // stop_ShopDataSet3
            // 
            this.stop_ShopDataSet3.DataSetName = "Stop_ShopDataSet3";
            this.stop_ShopDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // staffBindingSource
            // 
            this.staffBindingSource.DataMember = "staff";
            this.staffBindingSource.DataSource = this.stop_ShopDataSet3;
            // 
            // staffTableAdapter
            // 
            this.staffTableAdapter.ClearBeforeFill = true;
            // 
            // staffidDataGridViewTextBoxColumn
            // 
            this.staffidDataGridViewTextBoxColumn.DataPropertyName = "Staff_id";
            this.staffidDataGridViewTextBoxColumn.HeaderText = "Staff_id";
            this.staffidDataGridViewTextBoxColumn.Name = "staffidDataGridViewTextBoxColumn";
            // 
            // staffNameDataGridViewTextBoxColumn
            // 
            this.staffNameDataGridViewTextBoxColumn.DataPropertyName = "Staff_Name";
            this.staffNameDataGridViewTextBoxColumn.HeaderText = "Staff_Name";
            this.staffNameDataGridViewTextBoxColumn.Name = "staffNameDataGridViewTextBoxColumn";
            // 
            // mobilrDataGridViewTextBoxColumn
            // 
            this.mobilrDataGridViewTextBoxColumn.DataPropertyName = "Mobilr";
            this.mobilrDataGridViewTextBoxColumn.HeaderText = "Mobilr";
            this.mobilrDataGridViewTextBoxColumn.Name = "mobilrDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // designationDataGridViewTextBoxColumn
            // 
            this.designationDataGridViewTextBoxColumn.DataPropertyName = "Designation";
            this.designationDataGridViewTextBoxColumn.HeaderText = "Designation";
            this.designationDataGridViewTextBoxColumn.Name = "designationDataGridViewTextBoxColumn";
            // 
            // EmployeeDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.download__1_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(802, 484);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.EmpDelBtn);
            this.Controls.Add(this.EmpEditBtn);
            this.Controls.Add(this.AddEmpbtn);
            this.Controls.Add(this.EmpTabale);
            this.Controls.Add(this.SearchEmpDetals);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EmployeeDetails";
            this.Text = "EmployeeDetails";
            this.Load += new System.EventHandler(this.EmployeeDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.EmpTabale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stop_ShopDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SearchEmpDetals;
        private System.Windows.Forms.DataGridView EmpTabale;
        private System.Windows.Forms.Button EmpDelBtn;
        private System.Windows.Forms.Button EmpEditBtn;
        private System.Windows.Forms.Button AddEmpbtn;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label label7;
        private Stop_ShopDataSet3 stop_ShopDataSet3;
        private System.Windows.Forms.BindingSource staffBindingSource;
        private Stop_ShopDataSet3TableAdapters.staffTableAdapter staffTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobilrDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn designationDataGridViewTextBoxColumn;
    }
}