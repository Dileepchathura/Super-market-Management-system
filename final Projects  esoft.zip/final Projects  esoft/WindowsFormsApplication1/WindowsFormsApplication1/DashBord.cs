﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class DashBord : Form
    {
        public DashBord()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void DashBord_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Searchproducts searchpdct = new Searchproducts();
            searchpdct.Show();
            Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            EmployeeDetails empdtls = new EmployeeDetails();
            empdtls.Show();
            Visible = false;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Searchproducts empdtls = new Searchproducts();
            empdtls.Show();
            Visible = false;

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
             Searchproducts emp = new Searchproducts();
            emp.Show();
            Visible = false;
        }

        private void productbtn_Click(object sender, EventArgs e)
        {
            Searchproducts emp = new Searchproducts();
            emp.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)

        {
            // massege box option yes no

            string message = "Do you want to exit?";
            string title = "Conferm";
            MessageBoxButtons buttons = MessageBoxButtons.YesNoCancel;
            DialogResult result = MessageBox.Show(message, title, buttons,
            MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2,
            MessageBoxOptions.RightAlign, true);
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Visible = false;
            login log = new login();
            log.Show();

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            CustomerDetails cus = new CustomerDetails();
            cus.Show();
            Visible = false;

        }

        private void custemerbtn_Click(object sender, EventArgs e)
        {
            CustomerDetails cus = new CustomerDetails();
            cus.Show();
            Visible = false;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            EmployeeDetails emp = new EmployeeDetails();
            emp.Show();
            Visible = false;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Supplierdetails supl = new Supplierdetails();
            supl.Show();
            Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            userdetails user = new userdetails();
            user.Show();
            Visible = true;
        }

        private void Employeebtn_Click(object sender, EventArgs e)
        {
            EmployeeDetails emp = new EmployeeDetails();
            emp.Show();
            Visible = false;
        }

        private void Supplirbtn_Click(object sender, EventArgs e)
        {
            Supplierdetails supl = new Supplierdetails();
            supl.Show();
            Visible = false;
        }

        private void userbtn_Click(object sender, EventArgs e)
        {
            userdetails user = new userdetails();
            user.Show();
            Visible = true;
        }
       
    }
}
